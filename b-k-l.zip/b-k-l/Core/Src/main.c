/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "gpio.h"

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void); // 시스템 클럭 설정 함수
void HandleButtonPress(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIO_TypeDef* LED_GPIOx, uint16_t LED_Pin); // 버튼-LED 처리 함수
uint8_t IsButtonPressed(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin); // 버튼 입력 확인 함수 (디바운싱 포함)

/* Private user code ---------------------------------------------------------*/
/**
  * @brief 버튼 입력을 확인하고 LED를 제어하는 함수
  * @param GPIOx: 버튼이 연결된 GPIO 포트
  * @param GPIO_Pin: 버튼이 연결된 GPIO 핀
  * @param LED_GPIOx: LED가 연결된 GPIO 포트
  * @param LED_Pin: LED가 연결된 GPIO 핀
  */
void HandleButtonPress(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIO_TypeDef* LED_GPIOx, uint16_t LED_Pin)
{
    // 버튼이 눌렸는지 확인
    if (IsButtonPressed(GPIOx, GPIO_Pin))
    {
        // LED 켜기
        HAL_GPIO_WritePin(LED_GPIOx, LED_Pin, GPIO_PIN_SET);

        // 1초 대기
        HAL_Delay(1000);

        // LED 끄기
        HAL_GPIO_WritePin(LED_GPIOx, LED_Pin, GPIO_PIN_RESET);
    }
}

/**
  * @brief 버튼 입력을 확인하고 디바운싱 처리
  * @param GPIOx: 버튼이 연결된 GPIO 포트
  * @param GPIO_Pin: 버튼이 연결된 GPIO 핀
  * @retval 1: 버튼이 눌림, 0: 버튼이 눌리지 않음
  */
uint8_t IsButtonPressed(GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin)
{
    // 버튼이 눌렸는지 확인 (GPIO 상태가 LOW인 경우)
    if (HAL_GPIO_ReadPin(GPIOx, GPIO_Pin) == GPIO_PIN_RESET)
    {
        // 디바운싱을 위한 짧은 대기
        HAL_Delay(50);

        // 버튼 상태를 다시 확인
        if (HAL_GPIO_ReadPin(GPIOx, GPIO_Pin) == GPIO_PIN_RESET)
        {
            return 1; // 버튼이 안정적으로 눌렸음
        }
    }
    return 0; // 버튼이 눌리지 않음
}

/* Main function -------------------------------------------------------------*/
int main(void)
{
    /* HAL 라이브러리 초기화 */
    HAL_Init();

    /* 시스템 클럭 설정 */
    SystemClock_Config();

    /* GPIO 초기화 */
    MX_GPIO_Init();

    /* 메인 루프 */
    while (1)
    {
        // 버튼 1 -> LED 1 제어
        HandleButtonPress(GPIOA, GPIO_PIN_1, GPIOB, GPIO_PIN_0);

        // 버튼 2 -> LED 2 제어
        HandleButtonPress(GPIOA, GPIO_PIN_0, GPIOB, GPIO_PIN_1);

        // 버튼 3 -> LED 3 제어
        HandleButtonPress(GPIOA, GPIO_PIN_4, GPIOA, GPIO_PIN_2);

        // 버튼 4 -> LED 4 제어
        HandleButtonPress(GPIOC, GPIO_PIN_14, GPIOB, GPIO_PIN_6);
    }
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
